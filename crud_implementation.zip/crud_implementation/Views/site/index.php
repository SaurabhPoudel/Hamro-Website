<div id="reviews">
    <div class="col-left">
        <img src="public/images/restaurant.jpg">
    </div>
   <!--<div class="col-right">
        <article class="user-review">
            <div class="article-header">
                <img class="reviewer-avatar" src="public/images/user1-128x128.jpg">
                <span><b>Marshall M</b></span>
                <small>3 days ago</small>
            </div>
            <p class="article-body">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet magna interdum, efficitur libero eu, ullamcorper nibh. Nunc ac convallis enim, at lobortis nunc.
            </p>
        </article>
        <article class="user-review">
            <div class="article-header">
                <img class="reviewer-avatar" src="public/images/user3-128x128.jpg">
                <span><b>Jon Doe</b></span>
                <small>3 days ago</small>
            </div>
            <p class="article-body">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet magna interdum, efficitur libero eu, ullamcorper nibh. Nunc ac convallis enim, at lobortis nunc.
            </p>
        </article>
    </div>-->
</div>
<hr>
<h2 class="text-green">WELCOME TO HAMRO WEBSITE!</h2>